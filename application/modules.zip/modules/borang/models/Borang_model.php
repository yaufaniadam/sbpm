<?php
	class Borang_model extends CI_Model{

		//---------------------------------------------------
		// get all stndar
		public function add_dokumen_borang($data){
			$this->db->set('datetime', 'NOW()', FALSE);
			return $this->db->insert('ci_borang', $data);
		}

		public function get_all(){			
			$this->db->select('*');
        	$this->db->from('ci_borang');
       		$query=  $this->db->get();
        	return $query->result();
		}
		
	}

?>