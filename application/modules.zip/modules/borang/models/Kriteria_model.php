<?php
	class Kriteria_model extends CI_Model{

		//---------------------------------------------------
		// get all stndar
		public function get_all_kriteria(){
			$this->db->order_by("id", "asc");
			$query = $this->db->get('ci_kriteria');			
			return $result = $query->result_array();
		}

		//---------------------------------------------------
		// Get user detial by ID
		public function get_kriteria_by_id($id){
			$query = $this->db->get_where('ci_kriteria', array('id' => $id));
			return $result = $query->row_array();
		}

		//---------------------------------------------------
		// Edit kriteria
		public function edit_kriteria($data, $id){
			$this->db->where('id', $id);
			$this->db->update('ci_kriteria', $data);
			return true;
		}

		// Edit get kriteria beserta isi borangnya
		public function get_all_borang($unit, $tahun){
			$this->db->order_by("id", "asc");
			$query = $this->db->get('ci_kriteria');
			$borang = $query->result();
			$i=0;
			foreach ($borang as $b) {
				$borang[$i]->isi = $this->get_borang_by_kriteria($b->id, $unit, $tahun);
            	$i++;
			}
			return $borang;

		}

		// getborang by kriteria dan unit
		public function get_borang_by_kriteria($kriteria,$unit, $tahun){

			$this->db->select('*');
        	$this->db->from('ci_borang');
			$this->db->where('kriteria', $kriteria);
			$this->db->where('tahun', $tahun);
			$this->db->where('unit', $unit);

			$result = $this->db->get();
			$borang = $result->result_array();

			return $borang;
		}

		// getborang by kriteria dan unit
		public function get_tahun_borang_by_unit($unit){
	
			$this->db->select('*');
        	$this->db->from('ci_borang');
			$this->db->where('unit', $unit);
			$this->db->group_by('tahun');

			$result = $this->db->get();
			$tahun = $result->result_array();

			return $tahun;
		}
		
	}

?>