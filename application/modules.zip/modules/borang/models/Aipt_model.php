<?php
	class Aipt_model extends CI_Model{



		//---------------------------------------------------
		// get all stndar
		public function get_all_aipt_standar(){
			$this->db->order_by("id", "asc");
			$query = $this->db->get('ci_aipt_standar');			
			return $result = $query->result_array();
		}

		//---------------------------------------------------
		// Get user detial by ID
		public function get_aipt_standar_by_id($id){
			$query = $this->db->get_where('ci_aipt_standar', array('id' => $id));
			return $result = $query->row_array();
		}

		//---------------------------------------------------
		// Edit kriteria
		public function edit_aipt_standar($data, $id){
			$this->db->where('id', $id);
			$this->db->update('ci_aipt_standar', $data);
			return true;
		}

		// Edit get kriteria beserta isi borangnya
		public function get_all_aipt($tahun){
			
			$this->db->order_by("id", "asc");
			$query = $this->db->get('ci_aipt_standar');
			$aipt = $query->result();
			$i=0;
			foreach ($aipt as $a) {
				$aipt[$i]->isi = $this->get_aipt_by_standar($a->id, $tahun);
            	$i++;
			}
			return $aipt;

		}

		// getborang by kriteria dan unit
		public function get_aipt_by_standar($standar, $tahun){

			$this->db->select('*');
        	$this->db->from('ci_aipt');
			$this->db->where('standar', $standar);
			$this->db->where('tahun', $tahun);

			$result = $this->db->get();
			$borang = $result->result_array();

			return $borang;
		}

		// getborang by kriteria dan unit
		public function get_tahun_aipt(){
	
			$this->db->select('*');
        	$this->db->from('ci_aipt');
			$this->db->group_by('tahun');

			$result = $this->db->get();
			$tahun = $result->result_array();

			return $tahun;
		}

		// get all stndar
		public function add_dokumen_aipt($data){
			$this->db->set('datetime', 'NOW()', FALSE);
			return $this->db->insert('ci_aipt', $data);
		}
		
	}

?>