 <!-- Datatable style -->
 <section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body">
        <div class="col-md-6">
          <h4><i class="fa fa-graduation-cap"></i> &nbsp; Borang AIPT</h4>
        </div> 
        <div class="col-md-6 text-right">
            <a href="<?= base_url('borang/aipt/tambah/'); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Borang AIPT</a>
        </div>       
      </div>
    </div>
  </div>
  <?php 
  if($get_tahun) { ?>
    <div class="box">
        <div class="box-header with-border">
          <h4> Pilih tahun</h4>
        </div>
        <div class="box-body" > 
        <ul>
          <?php
            foreach ($get_tahun as $tahun ) { ?>
              <li><a href="<?php echo base_url('borang/aipt/detail/'. $tahun['tahun']); ?>" ><?php echo $tahun['tahun']; ?></a></li>    
          <?php } ?>
        </ul>
      </div>
    </div>

<?php
  } else {
    echo "Belum ada data";
  }
  ?>
  
</section>  


<!-- Modal -->
<div id="confirm-delete" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Hapus</h4>
      </div>
      <div class="modal-body">
        <p>Anda yakin ingin menghapus data ini?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <a class="btn btn-danger btn-ok">Hapus</a>
      </div>
    </div>

  </div>
</div>
  
<script type="text/javascript">
  $('#confirm-delete').on('show.bs.modal', function(e) {
  $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
  });
</script>

<script>
  $("#borang").addClass('active');
  $("#borang .submenu_upload").addClass('active');
</script>
