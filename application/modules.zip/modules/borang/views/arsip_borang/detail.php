 <!-- Datatable style -->
 <section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body">
        <div class="col-md-9">
          <h4><i class="fa fa-graduation-cap"></i> &nbsp; Borang Program Studi <?php echo $unit['nama_unit']; ?> Tahun <?php echo $this->uri->segment(4); ?></h4>
        </div> 
        <div class="col-md-3 text-right">
          <a href="<?= base_url('borang/tambah_borang/'. $unit['id'] ); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Borang</a>
        </div>       
      </div>
    </div>
  </div>

 <?php
    if($tahun) {
    foreach ($all_borang as $borang ) { ?>
      
    <div class="box">
        <div class="box-header with-border">
          <h4><?php echo $borang->keterangan; ?></h4>
        </div>
        <div class="box-body table-responsive" >
          <table id="standar" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th style="width:70%;">Dokumen Borang</th>
                <th style="text-align:center;">Jenis</th>
                <th style="text-align:center;">Tanggal</th>
                <th style="text-align:center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
              <?php 
              $isi = $borang->isi;

              if($isi) {
                foreach ($isi as $isi) {
              ?>
                <tr>
                  <td><?php echo $isi['keterangan']; ?></td>
                  <td style="text-align:center;"><?php if( $isi['type'] == 'b' ) { echo "Borang"; } else { echo "Lampiran"; }  ?></td>
                  <td style="text-align:center;"><?php echo $isi['datetime']; ?></td>
                  <td style="text-align:center;"><a target="_blank" title="Unduh" class="update btn btn-sm btn-success" href="<?php echo base_url( $isi['file_url']); ?>"> <i class="fa fa-download"></i></a> 
                  
                    <a title="Hapus" class="delete btn btn-sm btn-danger pull-right" data-href="<?= base_url('borang/hapus/'. $isi['id'] .'/'. $unit['id'] ); ?>" data-toggle="modal" data-target="#confirm-delete"> <i class="fa fa-trash-o"></i></a>
                  </td>            
                </tr> 
              <?php } //end freach
              }// endif ?>                               
            </tbody>
          </table>
          <!-- /.box-body -->
        </div>
      </div>
  

    <!-- /.box -->
  <?php } 
} else {?>
   <div class="box">
        <div class="box-header with-border">
          <h4> Pilih tahun</h4>
        </div>
        <div class="box-body" > 
   
    <ul>

    <?php   
      if ($get_tahun) {

        foreach ($get_tahun as $tahun ) { 
          echo "<li><a href='" . base_url('borang/detail/' . $unit['id']) . "/". $tahun['tahun'] ."' >".$tahun['tahun']."</a></li>";
        } 

      } else {
        echo "<li>Belum ada data</li>";
      }

      ?>
  </ul>
</div>
  </div>
  <?php }  

?>
</section>  


<!-- Modal -->
<div id="confirm-delete" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Hapus</h4>
      </div>
      <div class="modal-body">
        <p>Anda yakin ingin menghapus data ini?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <a class="btn btn-danger btn-ok">Hapus</a>
      </div>
    </div>

  </div>
</div>
  
<script type="text/javascript">
  $('#confirm-delete').on('show.bs.modal', function(e) {
  $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
  });
</script>

<script>
  $("#borang").addClass('active');
  $("#borang .submenu_upload").addClass('active');
</script>
