<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body">
        <div class="col-md-6">
          <h4><i class="fa fa-pencil"></i> &nbsp; Edit Kriteria</h4>
        </div>
        <div class="col-md-6 text-right">
          <a href="<?= base_url('borang/kriteria'); ?>" class="btn btn-success"><i class="fa fa-list"></i> Semua Kriteria</a>
          
        </div>
        
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
         
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <div class="box-body my-form-body">
          <?php if(isset($msg) || validation_errors() !== ''): ?>
              <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                  <?= validation_errors();?>
                  <?= isset($msg)? $msg: ''; ?>
              </div>
            <?php endif; ?>
           
            <?php echo form_open(base_url('borang/kriteria/edit/'. $kriteria['id']), 'class="form-horizontal"' )?> 
              <div class="form-group">
                <label for="nama_prodi" class="col-sm-2 control-label">Kriteria</label>

                <div class="col-sm-9">
                  <input type="text" name="kriteria" value="<?= $kriteria['kriteria']; ?>" class="form-control" id="kriteria" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="keterangan" class="col-sm-2 control-label">Keterangan</label>

                <div class="col-sm-9">
                  <input type="text" name="keterangan" value="<?= $kriteria['keterangan']; ?>" class="form-control" id="keterangan" placeholder="">
                </div>
              </div>
			 
              <div class="form-group">
                <div class="col-md-11">
                  <input type="submit" name="submit" value="Update Kriteria" class="btn btn-info pull-right">
                </div>
              </div>
            <?php echo form_close(); ?>
          </div>
          <!-- /.box-body -->
      </div>
    </div>
  </div>  

</section> 

 <script>
    $("#borang").addClass('active');
  </script>

