 <!-- Datatable style -->
<link rel="stylesheet" href="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.css">  
 <section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body">
        <div class="col-md-12">
          <h4><i class="fa fa-list"></i> &nbsp; Kriteria Borang</h4>
        </div>
    
        
      </div>
    </div>
  </div>


   <div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->
    <div class="box-body table-responsive">
      <table id="standar" class="table table-bordered table-striped ">
        <thead>
        <tr>
          <th>Kriteria</th>
          <th>Keterangan</th>
          <th style="text-align:center;">Aksi</th>
       
          
        </tr>
        </thead>
        <tbody>
          <?php foreach($all_kriteria as $row): ?>
          <tr>
            <td><?= $row['kriteria']; ?></td>
            <td><?= $row['keterangan']; ?></td>
            <td style="text-align:center;"><a title="Edit" class="update btn btn-sm btn-success" href="<?php echo base_url('borang/kriteria/edit/' . $row['id']); ?>"> <i class="fa fa-pencil-square-o"></i></a></td>
            
		      </tr>
          <?php endforeach; ?>
        </tbody>
       
      </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</section>  

<!-- DataTables -->
<script src="<?= base_url() ?>public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $("#standar").DataTable(
       "paging":   false,
        "ordering": false,
        "info":     false);
  });
</script> 

 <script>
    $("#borang").addClass('active');
    $("#borang .submenu_kriteria").addClass('active');
  </script>
