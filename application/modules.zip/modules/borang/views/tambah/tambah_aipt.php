<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body with-border">
        <div class="col-md-6">
          <h4><i class="fa fa-plus"></i> &nbsp; Tambah Borang AIPT</h4>
        </div>
        <div class="col-md-6 text-right">
          <a href="<?= base_url('borang/aipt/detail/' ); ?>" class="btn btn-success"><i class="fa fa-list"></i> Daftar Borang</a>
        </div> 
        
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <div class="box-body my-form-body">
          <?php if(isset($msg) || validation_errors() !== ''): ?>
              <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                  <?= validation_errors();?>
                  <?= isset($msg)? $msg: ''; ?>
              </div>
            <?php endif; ?>

           
            <?php if(!empty($error)):
              echo '<span class="alert alert-danger" style="display: block;">';
               foreach ($error as $item => $value):?>
                  <?php echo $item;?>: <?php echo $value;?>
            <?php endforeach; echo '</span>'; endif; ?>
      
            <?php echo form_open_multipart('borang/aipt/tambah/', 'class="form-horizontal"');?>

             <div class="form-group <?=form_error('keterangan')?"has-error":"" ?>">
                <label for="keterangan" class="col-sm-2 control-label">Keterangan </label>
                <div class="col-sm-9">
                  <input type="text" name="keterangan" class="form-control" id="keterangan" placeholder="" value="<?=!form_error('keterangan')?set_value('keterangan'):''?>">
                  <span class="help-block"><?php echo form_error('keterangan'); ?></span>
                </div>
              </div>
             
              <div class="form-group">
                <label for="standar" class="col-sm-2 control-label">Pilih Kategori</label>
                <div class="col-sm-9">
                  <select name="standar" class="form-control">
                    <option value="">Pilih Kategori <?php !form_error('standar')? $val = set_value('standar'): $val='' ; ?></option>
                    <?php foreach($all_standar as $row): ?>
                      <option value="<?= $row['id']; ?>" <?php if($val == $row['id'] ) { echo "selected=true"; }; ?> > <?= $row['keterangan']; ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div> 			  
			    
			        <div class="form-group">
                <label for="tahun" class="col-sm-2 control-label">Tahun</label>
                <div class="col-sm-9">
                  <select name="tahun" class="form-control">
                    <option value="">Pilih Tahun <?php !form_error('tahun')? $val = set_value('tahun'):'' ; ?></option>
                    <?php $year = date('Y');
					               for($i = $year-6; $i <=$year; $i++ ) { ?>
                          <option value="<?= $i; ?>" <?php if($val == $i) { echo "selected=true"; }; ?>> <?= $i; ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div> 


              <div class="form-group">
                <label for="file-upload" class="col-sm-2 control-label">Berkas Borang</label>
                <div class="col-sm-9">
                  <input type="file" name="userfile" class="form-control" id="file-upload" placeholder="" value="">
                  <p><small class="text-success">Ekstensi yang diiizinkan: doc,docx, xls, xlsx, ppt, pptx, odt, rtf, jpg, png, pdf</small></p>
                </div>
              </div>       

              <div class="form-group">
                <div class="col-md-11">
                  <input type="submit" name="submit" value="Tambah Borang" class="btn btn-info pull-right">
                </div>
              </div>

            <?php echo form_close(); ?>

            <?php if(!empty($upload_data)):
              echo '<br><h3>Uploaded File Detail: </h3>';
               foreach ($upload_data as $item => $value):?>
                <li><?php echo $item;?>: <?php echo $value;?></li>
            <?php endforeach; endif; ?>
       

          </div>
          <!-- /.box-body -->
      </div>
    </div>
  </div>  

</section> 


 <script>
    $("#borang").addClass('active');
  </script>



<script type="text/javascript">
  $('#file-borang').change(function() {
    var filepath = this.value;
    var m = filepath.match(/([^\/\\]+)$/);
    var filename = m[1];
    $('#filename').html(filename);

});
</script>