<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Prodi extends Unitkerja_Controller {
		public function __construct(){
			parent::__construct();
			$this->load->model('admin/unit_model', 'unit_model');
			$this->load->model('borang/kriteria_model', 'kriteria_model');
			$this->load->model('borang/borang_model', 'borang_model');
			$this->load->library('datatable'); 
		}

		public function index(){
	
			$user_id = $this->session->userdata('user_id');
			$prodi = $this->unit_model->get_unit_by_userid($user_id);

			//get unit by user_id

		

			$data['unit'] = $this->unit_model->get_unit_by_id($prodi['prodi'], 'p');

			if($data['unit']) {
		
				$data['all_borang'] =  $this->kriteria_model->get_all_borang($prodi['prodi']);

				$data['view'] = 'borang/arsip_borang/borang_prodi';
			

			} else {
				$data['view'] = 'admin/error';
				$data['error'] = 'Data tidak ditemukan, silakan memilih program studi terlebih dahulu';
			}
			
			$this->load->view('admin/layout', $data);
		}

		
		
	}

?>	