<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Aipt extends Admin_Controller {
		public function __construct(){
			parent::__construct();
			
			$this->load->model('borang/aipt_model', 'aipt_model');
			$this->load->library('datatable'); 
		}

		public function index(){

			//$data['unit'] = $this->unit_model->get_unit_by_id($id, 'p');			
			$data['title'] = 'Borang AIPT';
	

				$data['get_tahun'] = $this->aipt_model->get_tahun_aipt();

				$data['view'] = 'borang/arsip_borang/aipt';			

			$this->load->view('admin/layout', $data);
		}

		public function detail($tahun = 0){

				
			$data['title'] = 'Borang AIPT';
		

				$data['get_tahun'] = $this->aipt_model->get_tahun_aipt();
				$data['tahun'] = $tahun;
		
				$data['all_aipt'] =  $this->aipt_model->get_all_aipt($tahun);

				$data['view'] = 'borang/arsip_borang/detail_aipt';
			

			

			$this->load->view('admin/layout', $data);
		}

		

		public function hapus($id = 0, $unit){

			$query = $this->db->get_where('ci_borang', array('id' => $id));
			$file = $query->row_array()['file_url'];

			$tahun  = $query->row_array()['tahun'];

			if (!unlink($file)) {
				$this->session->set_flashdata('msg', 'Proses hapus gagal.');
				redirect(base_url('borang/detail/'. $unit.'/'.$tahun ));
			} else {

				$this->db->delete('ci_borang', array('id' => $id));
				$this->session->set_flashdata('msg', 'Data berhasil dihapus.');
				redirect(base_url('borang/detail/'. $unit .'/'.$tahun));
			}
		}	

		//---------------------------------------------------
		// File Upload
		public function tambah(){

			


				if($this->input->post('submit')){

					$this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required',   array('required' => '%s Wajib diisi.'));
					$this->form_validation->set_rules('standar', 'Standar', 'trim|required');
					$this->form_validation->set_rules('tahun', 'Tahun', 'trim|required');

					if ($this->form_validation->run() == FALSE) {

						$data['all_standar'] = $this->aipt_model->get_all_aipt_standar();
						$data['view'] = 'borang/tambah/tambah_aipt';
						$this->load->view('admin/layout', $data);

					} else {

						$tahun = $this->input->post('tahun');
						$standar = $this->input->post('standar');

						$upload_path = './uploads/aipt/'.$tahun;

						if (!is_dir($upload_path)) {
						     mkdir($upload_path, 0777, TRUE);					
						}
						$newName = "aipt-".$standar."-".$tahun."-".date('Y-m-d-H-i-s').pathinfo($_FILES["fileName"]['name'], PATHINFO_EXTENSION);
						$config = array(
								'upload_path' => $upload_path,
								'allowed_types' => "doc|docx|xls|xlsx|ppt|pptx|odt|rtf|jpg|png|pdf",
								'overwrite' => FALSE,
								'max_size' => "2048000", 
								'max_height' => "1200",
								'max_width' => "1900",
								'file_name' => $newName
							);

						$this->load->library('upload', $config);
						if($this->upload->do_upload()) {
							$data = array('upload_data' => $this->upload->data());

							foreach ($data as $upload) {				

								$data = array(
								
								'file_url' => $upload_path.'/'.$upload['file_name'],						
								'standar' => $this->input->post('standar'),
								'type' => 'b',	
								'tahun' => $this->input->post('tahun'),
								'keterangan' => $this->input->post('keterangan'),				
								);

								$data = $this->security->xss_clean($data);
								$result = $this->aipt_model->add_dokumen_aipt($data);
								if($result){
									$this->session->set_flashdata('msg', 'Borang AIPT berhasil diunggah!');
									redirect(base_url('borang/aipt/detail/'.$tahun ));
								} //endif $result

							} //end foreach


						} else {
							$data['error'] = array('error' => $this->upload->display_errors());
							$data['all_standar'] = $this->aipt_model->get_all_aipt_standar();
							$data['view'] = 'borang/tambah/tambah_aipt';
							$this->load->view('admin/layout', $data);
						} //endif do_upload()
					} //form_validation->run() 
				} else{
					$data['title'] = 'Tambah Borang';
					$data['all_standar'] = $this->aipt_model->get_all_aipt_standar();
					$data['view'] = 'borang/tambah/tambah_aipt';
					$this->load->view('admin/layout', $data);
				} //endif post('submit')
			
		} //endif tambah_borang()
		
	}

?>	