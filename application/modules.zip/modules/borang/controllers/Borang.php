<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Borang extends Admin_Controller {
		public function __construct(){
			parent::__construct();
			$this->load->model('admin/unit_model', 'unit_model');
			$this->load->model('borang/kriteria_model', 'kriteria_model');
			$this->load->model('borang/borang_model', 'borang_model');
			$this->load->library('datatable'); 
		}

		public function index(){
			$data['all_prodi'] =  $this->unit_model->get_all_prodi();
			$data['title'] = 'Borang Program Studi';
			$data['view'] = 'borang/arsip_borang/index';
			$this->load->view('admin/layout', $data);
		}

		public function detail($id = 0, $tahun = 0){

			$data['unit'] = $this->unit_model->get_unit_by_id($id, 'p');			
			$data['title'] = 'Borang Program Studi';
			if($data['unit']) {

				$data['get_tahun'] = $this->kriteria_model->get_tahun_borang_by_unit($id);
				$data['tahun'] = $tahun;
		
				$data['all_borang'] =  $this->kriteria_model->get_all_borang($id, $tahun);

				$data['view'] = 'borang/arsip_borang/detail';
			

			} else {
				$data['view'] = 'admin/error';
				$data['error'] = 'Data tidak ditemukan, silakan memilih program studi terlebih dahulu';
			}

			$this->load->view('admin/layout', $data);
		}

		public function hapus($id = 0, $unit){

			$query = $this->db->get_where('ci_borang', array('id' => $id));
			$file = $query->row_array()['file_url'];

			$tahun  = $query->row_array()['tahun'];

			if (!unlink($file)) {
				$this->session->set_flashdata('msg', 'Proses hapus gagal.');
				redirect(base_url('borang/detail/'. $unit.'/'.$tahun ));
			} else {

				$this->db->delete('ci_borang', array('id' => $id));
				$this->session->set_flashdata('msg', 'Data berhasil dihapus.');
				redirect(base_url('borang/detail/'. $unit .'/'.$tahun));
			}
		}	

		//---------------------------------------------------
		// File Upload
		public function tambah_borang($unit = 0){

			$data['unit'] = $this->unit_model->get_unit_by_id($unit, 'p');

			if($data['unit']) {

				if($this->input->post('submit')){

					$this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required',   array('required' => '%s Wajib diisi.'));
					$this->form_validation->set_rules('kriteria', 'Kriteria', 'trim|required');
					$this->form_validation->set_rules('tahun', 'Tahun', 'trim|required');

					if ($this->form_validation->run() == FALSE) {

						$data['all_kriteria'] = $this->kriteria_model->get_all_kriteria();
						$data['view'] = 'borang/tambah/tambah_borang';
						$this->load->view('admin/layout', $data);

					} else {

						$tahun = $this->input->post('tahun');
						$kriteria = $this->input->post('kriteria');

						$upload_path = './uploads/borang/'.$unit.'/'.$tahun;

						if (!is_dir($upload_path)) {
						     mkdir($upload_path, 0777, TRUE);					
						}
						$newName = "borang-".$kriteria."-".$unit."-".$tahun."-".date('Y-m-d-H-i-s').pathinfo($_FILES["fileName"]['name'], PATHINFO_EXTENSION);
						$config = array(
								'upload_path' => $upload_path,
								'allowed_types' => "doc|docx|xls|xlsx|ppt|pptx|odt|rtf|jpg|png|pdf",
								'overwrite' => FALSE,
								'max_size' => "2048000", 
								'max_height' => "1200",
								'max_width' => "1900",
								'file_name' => $newName
							);

						$this->load->library('upload', $config);
						if($this->upload->do_upload()) {
							$data = array('upload_data' => $this->upload->data());

							foreach ($data as $upload) {				

								$data = array(
								
								'file_url' => $upload_path.'/'.$upload['file_name'],						
								'kriteria' => $this->input->post('kriteria'),
								'unit' => $unit,
								'type' => 'b',	
								'tahun' => $this->input->post('tahun'),
								'keterangan' => $this->input->post('keterangan'),				
								);

								$data = $this->security->xss_clean($data);
								$result = $this->borang_model->add_dokumen_borang($data);
								if($result){
									$this->session->set_flashdata('msg', 'Borang berhasil diunggah!');
									redirect(base_url('borang/detail/'. $unit.'/'.$tahun ));
								} //endif $result

							} //end foreach


						} else {
							$data['error'] = array('error' => $this->upload->display_errors());
							$data['all_kriteria'] = $this->kriteria_model->get_all_kriteria();
							$data['view'] = 'borang/tambah/tambah_borang';
							$this->load->view('admin/layout', $data);
						} //endif do_upload()
					} //form_validation->run() 
				} else{
					$data['title'] = 'Tambah Borang';
					$data['all_kriteria'] = $this->kriteria_model->get_all_kriteria();
					$data['view'] = 'borang/tambah/tambah_borang';
					$this->load->view('admin/layout', $data);
				} //endif post('submit')
			} else {

				$data['view'] = 'admin/error';
				$data['error'] = 'Silakan memilih program studi terlebih dahulu';
				$this->load->view('admin/layout', $data);
			} //endif $data

		} //endif tambah_borang()
		
	}

?>	