<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class Kriteria extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('borang/kriteria_model', 'kriteria_model');
			$this->load->library('datatable'); // loaded my custom serverside datatable library
		}

		public function index(){
			$data['all_kriteria'] =  $this->kriteria_model->get_all_kriteria();
			$data['title'] = 'Kriteria Borang';
			$data['view'] = 'borang/kriteria/all_kriteria';
			$this->load->view('admin/layout', $data);
		}		

		public function edit($id = 0){

			$data['kriteria'] = $this->kriteria_model->get_kriteria_by_id($id);

			if($data['kriteria']){

			if($this->input->post('submit')){
				$this->form_validation->set_rules('kriteria', 'Kriteria', 'trim|required');
				$this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required');	

				if ($this->form_validation->run() == FALSE) {
					$data['kriteria'] = $this->kriteria_model->get_kriteria_by_id($id);
					$data['view'] = 'borang/kriteria/edit_kriteria';
					$this->load->view('admin/layout', $data);
				}
				else{
					$data = array(
						'kriteria' => $this->input->post('kriteria'),
						'keterangan' => $this->input->post('keterangan'),
						
					);
					$data = $this->security->xss_clean($data);
					$result = $this->kriteria_model->edit_kriteria($data, $id);
					if($result){
						$this->session->set_flashdata('msg', 'Kriteria berhasil diubah!');
						redirect(base_url('borang/kriteria'));
					}
				}
			}
			else{
				$data['kriteria'] = $this->kriteria_model->get_kriteria_by_id($id);
				$data['view'] = 'borang/kriteria/edit_kriteria';
				$this->load->view('admin/layout', $data);
			}

			}else {
				$data['view'] = 'admin/error';
				$data['error'] = 'Kriteria belum dipilih';
				$this->load->view('admin/layout', $data);
			}
		}

	}


?>