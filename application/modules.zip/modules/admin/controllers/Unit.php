<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class Unit extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('admin/unit_model', 'unit_model');
			$this->load->model('admin/user_model', 'user_model');
			$this->load->model('kinerja/kinerjaunit_model', 'kinerjaunit_model');
			$this->load->library('datatable'); // loaded my custom serverside datatable library
		}

		public function index(){
			$data['all_unit'] =  $this->unit_model->get_all_unit_kerja();
			$data['title'] = 'Unit Kerja';
			$data['view'] = 'admin/unit/all_unit';
			$this->load->view('layout', $data);
		}		

	
		public function tambah_unit(){
			if($this->input->post('submit')){
				$this->form_validation->set_rules('nama_unit', 'Nama unit', 'trim|required');

				if ($this->form_validation->run() == FALSE) {
					$data['view'] = 'admin/unit/tambah_unit';
					$this->load->view('layout', $data);
				}
				else{
					$data = array(
						'nama_unit' => $this->input->post('nama_unit'),
						'kode' => 'b',
						'singkatan' => $this->input->post('singkatan'),
						'induk' => '0',
					
					);
					$data = $this->security->xss_clean($data);
					$result = $this->unit_model->add_unit($data);
					if($result){
						$this->session->set_flashdata('msg', 'Unit Kerja telah ditambahkan!');
						redirect(base_url('admin/unit'));
					}
				}
			}
			else{
				$data['view'] = 'admin/unit';
				$this->load->view('layout', $data);
			}
			
		}

		

		public function edit($id = 0){
			if($this->input->post('submit')){
				$this->form_validation->set_rules('nama_unit', 'Nama unit', 'trim|required');

			
					$data = array(
						'nama_unit' => $this->input->post('nama_unit'),
						'singkatan' => $this->input->post('singkatan'),
			
					);
					$data = $this->security->xss_clean($data);
					$result = $this->unit_model->edit_unit($data, $id);
					if($result){
						$this->session->set_flashdata('msg', 'Unit telah diperbarui!');
						redirect(base_url('admin/unit'));
					}
				
			}
			else{
				$data['unit'] = $this->unit_model->get_unit_by_id($id,'b');
				$data['view'] = 'admin/unit/edit';
				$this->load->view('layout', $data);
			}
		}

		

		public function del($id = 0, $uri = NULL){	
			$this->db->delete('ci_unit_kerja', array('id' => $id));
			$this->session->set_flashdata('msg', 'Data berhasil dihapus!');
			redirect(base_url('admin/unit/'));
		}

		public function kantor() {

			$data['all_kantor'] =  $this->unit_model->get_all_kantor();
			$data['title'] = 'Kantor Pusat dan Cabang';
			$data['view'] = 'admin/unit/all_kantor';
			$this->load->view('layout', $data);
		}

		public function tambah_kantor(){
			if($this->input->post('submit')){
				$this->form_validation->set_rules('nama_kantor', 'Nama kantor', 'trim|required');
				$this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
				$this->form_validation->set_rules('telp', 'Telepon', 'trim|required');

				if ($this->form_validation->run() == FALSE) {
					$data['unit'] = $this->unit_model->get_all_unit_kerja();
					$data['title'] = "Tambah Kantor Cabang";
					$data['view'] = 'admin/unit/tambah_kantor';
					$this->load->view('layout', $data);
				}
				else{
					$data = array(
						'kantor' => $this->input->post('nama_kantor'),				
						'alamat' => $this->input->post('alamat'),
						'telp' => $this->input->post('telp'),
						
					
					);
					$data = $this->security->xss_clean($data);
					$result = $this->unit_model->add_kantor($data);
					if($result){
						$this->session->set_flashdata('msg', 'Unit Kerja telah ditambahkan!');
						redirect(base_url('admin/unit/kantor'));
					}
				}
			}
			else{
				$data['unit'] = $this->unit_model->get_all_unit_kerja();
				$data['title'] = "Tambah Kantor Cabang";
				$data['view'] = 'admin/unit/tambah_kantor';
				$this->load->view('layout', $data);
			}
			
		}

		public function edit_kantor($id=0){
			if($this->input->post('submit')){
				$this->form_validation->set_rules('nama_kantor', 'Nama kantor', 'trim|required');
				$this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
				$this->form_validation->set_rules('telp', 'Telepon', 'trim|required');

				if ($this->form_validation->run() == FALSE) {
					$data['unit'] = $this->unit_model->get_all_unit_kerja();
					$data['title'] = "Ubah Kantor Cabang";
					$data['view'] = 'admin/unit/edit_kantor';
					$this->load->view('layout', $data);
				}
				else{
					$data = array(
						'kantor' => $this->input->post('nama_kantor'),				
						'alamat' => $this->input->post('alamat'),
						'telp' => $this->input->post('telp'),
						'id_unit'=>implode(',',$this->input->post('id_unit')),
						
					
					);
					$data = $this->security->xss_clean($data);
					$result = $this->unit_model->edit_kantor($data,$id);
					if($result){
						$this->session->set_flashdata('msg', 'Unit Kerja telah ditambahkan!');
						redirect(base_url('admin/unit/kantor'));
					}
				}
			}
			else{
				$data['unit'] = $this->unit_model->get_all_unit_kerja();
				$data['kantor'] = $this->unit_model->get_kantor_by_id($id);
				$data['title'] = "Ubah Kantor Cabang";
				$data['view'] = 'admin/unit/edit_kantor';
				$this->load->view('layout', $data);
			}
			
		}

		public function detail_kantor($id = 0){
			$data['penempatan'] = $this->user_model->get_penempatan_by_kantor($id);
			$data['kantor'] = $this->unit_model->get_kantor_by_id($id);
			$data['view'] = 'admin/unit/detail_kantor';
			$this->load->view('layout', $data);
		}

		public function detail_unit($kantor = 0 , $id = 0){			
			$data['kantor'] = $this->unit_model->get_kantor_by_id($kantor);
			$data['unit'] = $this->unit_model->get_unit_by_id($id);
			$data['hrd'] = $this->kinerjaunit_model->get_hrd($id, $kantor);
			$data['view'] = 'admin/unit/detail_unit';
			$this->load->view('layout', $data);
		}


	}


?>