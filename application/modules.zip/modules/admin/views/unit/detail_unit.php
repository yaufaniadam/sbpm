<?php 
  $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
  $uri_segments = explode('/', $uri_path);
  $current_kantor = $uri_segments[5];
  $current_unit = $uri_segments[6];

?>
 <section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body">
        <div class="col-md-6">
          <h4><i class="fa fa-building"></i> &nbsp; BMT UMY <?= $kantor['kantor'];?></h4>
        </div>
        <div class="col-md-6 text-right">
         
        </div>
        
      </div>
    </div>
  </div>


  <div class="row">
    <div class="col-md-12">
       <div class="box">
        <div class="box-header with-border">
           <h4>Unit Kerja <?=get_unit_kerja_by_id($current_unit); ?> </h4>
        </div>


        <?php $kinerja_unit = $unit['kode']; ?>
        <!-- /.box-header -->
        <div class="box-body table-responsive">
          <?php if($kinerja_unit == 'hrd') { ?>


            <?php if(isset($msg) || validation_errors() !== ''): ?>
              <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                  <?= validation_errors();?>
                  <?= isset($msg)? $msg: ''; ?>
              </div>
            <?php endif; ?>
           
            <?php echo form_open(base_url('kinerja/kinerjaunit/add_hrd/'.$current_kantor ."/" . $current_unit), 'class="form-horizontal"' )?> 
           
            <?php
              //get current month

              if(! $hrd['periode_bln'] ) {       
                  $this_month= date("n");
              } else {
                $this_month= $hrd['periode_bln'];
              }
            ?>
              <div class="form-group">
                <label for="periode" class="col-sm-6 control-label">Periode</label>
                <div class="col-sm-5">
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="input-group">
                        <select name="periode_bln" class="form-control" id="periode_bln" >
                          <option value="1" <?php if($this_month == 1 ) { echo "selected";} ?> >Januari</option>
                          <option value="2" <?php if($this_month == 2 ) { echo "selected";} ?>>Februari</option>
                          <option value="3" <?php if($this_month == 3 ) { echo "selected";} ?>>Maret</option>
                          <option value="4" <?php if($this_month == 4 ) { echo "selected";} ?>>April</option>
                          <option value="5" <?php if($this_month == 5 ) { echo "selected";} ?>>Mei</option>
                          <option value="6" <?php if($this_month == 6 ) { echo "selected";} ?>>Juni</option>
                          <option value="7" <?php if($this_month == 7 ) { echo "selected";} ?>>Juli</option>
                          <option value="8" <?php if($this_month == 8 ) { echo "selected";} ?>>Agustus</option>
                          <option value="9" <?php if($this_month == 9 ) { echo "selected";} ?>>September</option>
                          <option value="10" <?php if($this_month == 10 ) { echo "selected";} ?>>Oktober</option>
                          <option value="11" <?php if($this_month == 11 ) { echo "selected";} ?>>November</option>
                          <option value="12" <?php if($this_month == 12 ) { echo "selected";} ?>>Desember</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="input-group">
                       <select name="periode_thn" class="form-control" id="periode_thn" >
                          <option value="2019" <?php if($hrd['periode_thn'] == "2019" ) { echo "selected";} ?> >2019</option>
                          <option value="2020" <?php if($hrd['periode_thn'] == "2020" ) { echo "selected";} ?> >2020</option>                        
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>  

              <div class="form-group">
                <label for="nama_prodi" class="col-sm-6 control-label">Jenis Pengajian</label>
                <div class="col-sm-3">
                  <div class="input-group">            
                    <input type="text" name="jenis pengajian" class="form-control" value="<?php if(validation_errors()) {echo set_value('pelatihan'); } else { echo $hrd['jenis_pengajian']; }  ?>" placeholder="">
                 
                  </div>
                </div>
              </div>                

              <div class="form-group">
                <div class="col-md-11">
                  <input type="submit" name="submit" value="Simpan" class="btn btn-info pull-right">
                </div>
              </div>
            <?php echo form_close(); ?>
          <?php } //endif HRD ?> 
        </div>
        <!-- /.box-body -->
      </div>
    </div>
    
  </div>
  <!-- /.box -->
</section>  



<script>
 
  //for nav
  $("#kantor<?= $kantor['id'];?>").addClass('active');
  $("#kantor<?= $kantor['id'];?> .submenu_kantor<?=$current_unit;?>").addClass('active');

</script>
