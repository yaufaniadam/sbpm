<?php
	class Unit_model extends CI_Model{

		public function add_unit($data){
			$this->db->insert('ci_unit_kerja', $data);
			return true;
		}
		
		//---------------------------------------------------
		// get all unit records
		public function get_all_unit_kerja(){
			$wh =array();
			$query = $this->db->get('ci_unit_kerja');
		
			return $result = $query->result_array();
		}

		
		//---------------------------------------------------
		// Count total unit for pagination
		public function count_all_unit(){
			return $this->db->count_all('ci_unit_kerja');
		}

		

		//---------------------------------------------------
		// get all units for server-side datatable with advanced search
		public function get_all_unit_by_advance_search(){
			$wh =array();
			$SQL ='SELECT * FROM ci_unit_kerja';
			if($this->session->unitdata('unit_search_type')!='')
			$wh[]="is_active = '".$this->session->unitdata('unit_search_type')."'";
			if($this->session->unitdata('unit_search_from')!='')
			$wh[]=" `created_at` >= '".date('Y-m-d', strtotime($this->session->unitdata('unit_search_from')))."'";
			if($this->session->unitdata('unit_search_to')!='')
			$wh[]=" `created_at` <= '".date('Y-m-d', strtotime($this->session->unitdata('unit_search_to')))."'";

			$wh[] = " is_admin = 0";
			if(count($wh)>0)
			{
				$WHERE = implode(' and ',$wh);
				return $this->datatable->LoadJson($SQL,$WHERE);
			}
			else
			{
				return $this->datatable->LoadJson($SQL);
			}
		}

		//---------------------------------------------------
		// Get unit detial by ID
		public function get_unit_by_id($id){
			$query = $this->db->get_where('ci_unit_kerja', array('id' => $id));
			return $result = $query->row_array();
		}

		
		//---------------------------------------------------
		// Edit unit Record
		public function edit_unit($data, $id){
			$this->db->where('id', $id);
			$this->db->update('ci_unit_kerja', $data);
			return true;
		}

		//---------------------------------------------------
		// Get unit detial by userID
		public function get_unit_by_userid($user_id){
			//$this->db->select('prodi');
			$query = $this->db->get_where('ci_users', array('id' => $user_id));	
			return $result = $query->row_array();
		}

		//---------------------------------------------------
		// get all unit records
		public function get_all_kantor(){
			$query = $this->db->get('ci_kantor');		
			return $result = $query->result_array();
		}


		public function add_kantor($data){
			$this->db->insert('ci_kantor', $data);
			return true;
		}

		// Edit unit Record
		public function edit_kantor($data, $id){
			$this->db->where('id', $id);
			$this->db->update('ci_kantor', $data);
			return true;
		}

		// Get unit detial by ID
		public function get_kantor_by_id($id){
			//$this->db->select('prodi');
			$query = $this->db->get_where('ci_kantor', array('id' => $id));	
			return $result = $query->row_array();
		}
		

	}

?>