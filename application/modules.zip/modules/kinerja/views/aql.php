<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body with-border">
        <div class="col-md-6">
          <h4><i class="fa fa-user"></i> &nbsp; Kinerja Individu</h4>
        </div>       
      </div>

      <div class="box">
        <div class="box-header with-border">
          <h4>Hifdz Al’Aql (Pemeliharaan Akal) <a href="" class="btn btn-default btn-sm pull-right">Lihat periode lainnya</a> </h4>

        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <div class="box-body my-form-body">
          <?php if(isset($msg) || validation_errors() !== ''): ?>
              <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                  <?= validation_errors();?>
                  <?= isset($msg)? $msg: ''; ?>
              </div>
            <?php endif; ?>
           
            <?php echo form_open(base_url('kinerja/individu/aql'), 'class="form-horizontal"' )?> 
           
            <?php
              //get current month

              if(! $individu_aql['periode_bln'] ) {       
                  $this_month= date("n");
              } else {
                $this_month= $individu_aql['periode_bln'];
              }
            ?>
              <div class="form-group">
                <label for="periode" class="col-sm-6 control-label">Periode</label>
                <div class="col-sm-5">
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="input-group">
                        <select name="periode_bln" class="form-control" id="periode_bln" >
                          <option value="1" <?php if($this_month == 1 ) { echo "selected";} ?> >Januari</option>
                          <option value="2" <?php if($this_month == 2 ) { echo "selected";} ?>>Februari</option>
                          <option value="3" <?php if($this_month == 3 ) { echo "selected";} ?>>Maret</option>
                          <option value="4" <?php if($this_month == 4 ) { echo "selected";} ?>>April</option>
                          <option value="5" <?php if($this_month == 5 ) { echo "selected";} ?>>Mei</option>
                          <option value="6" <?php if($this_month == 6 ) { echo "selected";} ?>>Juni</option>
                          <option value="7" <?php if($this_month == 7 ) { echo "selected";} ?>>Juli</option>
                          <option value="8" <?php if($this_month == 8 ) { echo "selected";} ?>>Agustus</option>
                          <option value="9" <?php if($this_month == 9 ) { echo "selected";} ?>>September</option>
                          <option value="10" <?php if($this_month == 10 ) { echo "selected";} ?>>Oktober</option>
                          <option value="11" <?php if($this_month == 11 ) { echo "selected";} ?>>November</option>
                          <option value="12" <?php if($this_month == 12 ) { echo "selected";} ?>>Desember</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="input-group">
                       <select name="periode_thn" class="form-control" id="periode_thn" >
                          <option value="2019" <?php if($individu_aql['periode_thn'] == "2019" ) { echo "selected";} ?> >2019</option>
                          <option value="2020" <?php if($individu_aql['periode_thn'] == "2020" ) { echo "selected";} ?> >2020</option>                        
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>  

              <div class="form-group">
                <label for="nama_prodi" class="col-sm-6 control-label">Jumlah Pelatihan yang diikuti</label>
                <div class="col-sm-3">
                  <div class="input-group">            
                    <input type="text" name="pelatihan" class="form-control" value="<?php if(validation_errors()) {echo set_value('pelatihan'); } else { echo $individu_aql['pelatihan']; }  ?>" placeholder="">
                    <span class="input-group-addon"> / bulan</span>
                  </div>
                </div>
              </div>  

              <div class="form-group">
                <label for="inovasi_kepada_bmt" class="col-sm-6 control-label">Inovasi yang disampaikan kepada BMT</label>
                <div class="col-sm-3">
                  <div class="input-group">         
                    <input type="number" name="inovasi_kepada_bmt" class="form-control" value="<?php if(validation_errors()) {echo set_value('inovasi_kepada_bmt'); } else { echo $individu_aql['inovasi_kepada_bmt']; }  ?>"><span class="input-group-addon"> / bulan</span>
                  </div>
                </div>
              </div>  

              <div class="form-group">
                <label for="usulan_dipakai" class="col-sm-6 control-label">Usulan Inovasi yang dipakai oleh BMT</label>
                <div class="col-sm-3">
                  <div class="input-group">
                    <input type="number" name="usulan_dipakai" class="form-control" value="<?php if(validation_errors()) {echo set_value('usulan_dipakai'); } else { echo $individu_aql['usulan_dipakai']; }  ?>"><span class="input-group-addon"> / bulan</span>
                  </div>
                </div>
              </div> 

              <div class="form-group">
                <label for="kajian_rutin" class="col-sm-6 control-label">Kajian rutin mingguan dalam sebulan</label>
                <div class="col-sm-3">
                  <div class="input-group">
                    <input type="number" name="kajian_rutin" class="form-control" value="<?php if(validation_errors()) {echo set_value('kajian_rutin'); } else { echo $individu_aql['kajian_rutin']; }  ?>" ><span class="input-group-addon"> / bulan</span>
                  </div>
                </div>
              </div> 

              <div class="form-group">
                <div class="col-md-11">
                  <input type="submit" name="submit" value="Simpan" class="btn btn-info pull-right">
                </div>
              </div>
            <?php echo form_close(); ?>
          </div>
          <!-- /.box-body -->
      </div>
    </div><!-- /.col  -->
  </div><!-- /.row  -->
  
</section> 

<script src="<?= base_url() ?>public/plugins/datepicker/bootstrap-datepicker.js"></script>

<script>
  $("#kinerja_individu").addClass('active');
  $("#kinerja_individu .submenu_aql").addClass('active');
</script