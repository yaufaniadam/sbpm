<?php
	class Individu_model extends CI_Model{

		public function add_individu_din($data){
			
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_din', array('user_id' => $id));

			if($query->row_array()) {
				$this->db->update('ci_individu_din', $data);
			} else {
				$this->db->insert('ci_individu_din', $data);
			}

			return true;		
		}

		public function get_individu_din(){
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_din', array('user_id' => $id));
			return $result = $query->row_array();
		}
		

		public function add_individu_nafs($data){
			
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_nafs', array('user_id' => $id));
			
			if($query->row_array()) {
				$this->db->update('ci_individu_nafs', $data);
			} else {
				$this->db->insert('ci_individu_nafs', $data);
			}

			return true;		
		}

		public function get_individu_nafs(){
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_nafs', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function add_individu_aql($data){
			
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_aql', array('user_id' => $id));
			
			if($query->row_array()) {
				$this->db->update('ci_individu_aql', $data);
			} else {
				$this->db->insert('ci_individu_aql', $data);
			}

			return true;		
		}

		public function get_individu_aql(){
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_aql', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function add_individu_nasb($data){
			
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_nasb', array('user_id' => $id));
			
			if($query->row_array()) {
				$this->db->update('ci_individu_nasb', $data);
			} else {
				$this->db->insert('ci_individu_nasb', $data);
			}

			return true;		
		}

		public function get_individu_nasb(){
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_nasb', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function add_individu_mal($data){
			
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_mal', array('user_id' => $id));
			
			if($query->row_array()) {
				$this->db->update('ci_individu_mal', $data);
			} else {
				$this->db->insert('ci_individu_mal', $data);
			}

			return true;		
		}

		public function get_individu_mal(){
			$id = $this->session->userdata('user_id');
			$query = $this->db->get_where('ci_individu_mal', array('user_id' => $id));
			return $result = $query->row_array();
		}

		//get data untuk keperluan ditampilkan pada halaman profil

		public function get_individu_din_grafik($id=0){			
			$query = $this->db->get_where('ci_individu_din', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function get_individu_nafs_grafik($id=0){			
			$query = $this->db->get_where('ci_individu_nafs', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function get_individu_aql_grafik($id=0){			
			$query = $this->db->get_where('ci_individu_aql', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function get_individu_mal_grafik($id=0){			
			$query = $this->db->get_where('ci_individu_mal', array('user_id' => $id));
			return $result = $query->row_array();
		}

		public function get_individu_nasb_grafik($id=0){			
			$query = $this->db->get_where('ci_individu_nasb', array('user_id' => $id));
			return $result = $query->row_array();
		}
	}

?>